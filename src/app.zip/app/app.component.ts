import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet } from '@angular/router';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { PokemonCardComponent } from './pokemon-card/pokemon-card.component';
import { Pokemon } from './app.interface';
import { Observable } from 'rxjs';

const API_URL = 'https://pokeapi.co/api/v2/pokemon/';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet, HttpClientModule, PokemonCardComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss',
})
export class AppComponent implements OnInit {
  title = 'pokedex de los reyes 2008';
  pokemons: Pokemon[] = [];

  constructor(private readonly httpClient: HttpClient) {}

  ngOnInit(): void {
    for (let i = 1; i <= 20; i++) {
      this.httpClient.get<Pokemon>(API_URL + i).subscribe((item) => {
        this.pokemons.push(item);
      });
    }
    let sherlock = {
      surname: 'Holmes',
      address: 'London',
    };
    let john = {
      surname: 'Watson',
      address: sherlock.address,
    };
    john.surname = 'Lennon';
    john.address = 'Malibu';
    console.log(sherlock.surname); // ?
    console.log(sherlock.address); // ?
    console.log(john.surname); // ?
    console.log(john.address); // ?
  }
}
